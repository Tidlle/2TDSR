import React from 'react';
import {View, Text, TextInput, Button} from "react-native";

function Principal() {
  return(
  <View style={{flex: 1, marginTop: 60, marginLeft: 20, backgroundColor: 'white'}}> 
    <Text style={{fontSize: 32, marginBottom: 25}}>Pizzaria - Gestão do Cardápio</Text>
    <Text>Sabor da Pizza:</Text>
    <TextInput/>
    <Text>Preço:</Text>
    <TextInput></TextInput>
    <Text>Ingredientes:</Text>
    <Button title='Salvar'></Button>
  </View>
  )
}

export default Principal;
