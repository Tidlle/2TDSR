/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.uam.main;

/**
 *
 * @author MSWagner
 */
public class Main {

    public static void main(String args[]) {
        exemplo1();
    }
    
    public static void exemplo1() {
        Pessoa pedro = new Pessoa("Pedro", 24);
        
        System.out.println("A pessoa se chama " + 
                pedro.getNome() + " e ela tem " + 
                pedro.getIdade() + " anos.");
        
        pedro.setIdade(25);
        
        System.out.println("A pessoa se chama " + 
                pedro.getNome() + " e ela tem " + 
                pedro.getIdade() + " anos.");
        
        pedro.andar();
    }
}